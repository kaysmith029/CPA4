Picture this, you in aisle 9 surrounded by the overwhelming choice of a million chips. Do yo pick doritios? no. Regular old lays? no you want some variety. Maybe you should go with what you got lost time. But you don't remember? Okay what about the eggs? did you check the date on those before you left? No... Golly. This all could have been avoided if you would have downloaded the app you saw when scrolling through the app store. Wasn't its main purpose to make grocery shopping easier for you? to render the paper grocery list obsolete?

Food Link's purpose is just that. This app aims to categorize your food as you buy it. Whether you enter it in manually, choose it from the drop down list of foods or scan the item's barcode. You never have to bring a list to the store again with this app in hand. Say goodbye to remembering best by dates! We have you covered.

Screenshots are loocated in the possible foods tab of the app.

For this app I used JSON, stack naviagator, and npm.

